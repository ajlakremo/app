import React from 'react';
import Chat from "./components/Chat.js";

function App() {
  return (
    <div>
      <Chat></Chat>
    </div>
    
    
  );
}

export default App;
