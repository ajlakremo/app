import React from "react";
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Avatar from '@material-ui/core/Avatar';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Divider from '@material-ui/core/Divider';
import "./Message.css";


const Message = ({user, text, currentUser}) => {

    var sentByCurrentUser = false;
    var admin = false;
    if(user == currentUser) sentByCurrentUser = true;
    if(user == 'admin') {admin = true;}

return (
        sentByCurrentUser ?
         ( 
            <span class="u2 chat">{text}</span>
        ) 
        :(
            admin ?
        (
            <span class="u3 chat">{text} </span>

        ):
        (   
            <span class="u1 chat">{text} </span>
    
    ))
 );
}
 export default Message;