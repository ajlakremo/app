import React from "react";
import Button from '@material-ui/core/Button';
import io from "socket.io-client";
import "./Chat.css";
import ActiveUsers from "./ActiveUsers.js";
import Messages from "./Messages.js";

var socket; 

class Chat extends React.Component{
    constructor(props){
        super(props);

        this.state = {
            user:'',
            users: [],
            message:'',
            messages:[]
        };
        this.sendMessage = this.sendMessage.bind(this);

        
    }
sendMessage = e => {
        e.preventDefault();
        socket.emit('sendMessage', { user:this.state.user, message: this.state.message });
        this.setState({message: ''});
}

componentDidMount(){
    socket = io.connect('http://localhost:5000/');

    socket.on('activeUsers', ({ users }) => {
        this.setState({users: users});

        var index = this.state.users.findIndex((user) => user.id === socket.id); 
        
        this.setState({user: this.state.users[index]});
    });
  

    socket.on('messages', message => {
        this.setState({ 
            messages: this.state.messages.concat(message)
          });
        
        console.log(this.state.messages);
      });
}

render(){
        return (
        <div className="outerContainer">
            <div className="container">
                <div id ="userlist">
                    <ActiveUsers  users = {this.state.users} ></ActiveUsers>
                </div>

                <div id = "chatboard">
                    <div className = "header" style = {{padding: '15px'}}  align='center' >
                        Global Chat
                    </div> 
                    <div id="messages">
                        <Messages messages = {this.state.messages} currentUser = {this.state.user}></Messages>
                    </div>
                    <div id = "input">              
                    <input type="text" class="msger-input" placeholder="Enter your message..."
                        value={this.state.message} onChange={e => this.setState({message: e.target.value})}/>
                        
                    <Button 
                        id = "button"
                        className="button"
                        style = {{width: '15%', height:'30px'}}
                        variant="outlined" 
                        color="primary"
                        onClick={this.sendMessage}>
                            Send
                        </Button>
                        </div>
                </div>
            
        </div>

        </div>
        );
    }
}

export default Chat;