import React from "react";
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import Typography from '@material-ui/core/Typography';
import "./Chat.css";


const ActiveUsers = ({users}) => (
    <div>   
        <div className = "header" style = {{padding: '15px'}}>
        <Typography variant="h7">
            Active Users
        </Typography>
        </div>

    
    <List width="auto">

    {users.map(({name}) => (
        <div>
        <ListItem alignItems="flex-start" >
        <Chip variant="outlined" color="primary" avatar={<Avatar src="/static/images/avatar/1.jpg" />} label = {name}/> 
        </ListItem>
        <Divider light /> 
        </div>
    ))}
     </List>
     </div>
    );

export default ActiveUsers;