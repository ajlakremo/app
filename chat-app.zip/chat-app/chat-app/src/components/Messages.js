import React from "react";
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Avatar from '@material-ui/core/Avatar';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Divider from '@material-ui/core/Divider';
import Message from './Message.js';
import "./Messages.css";

const Messages = ({messages, currentUser}) => (
    <div>
       {messages.map((message, i) => <div key={i}><Message user = {message.user} text = {message.text.message} currentUser = {currentUser.name}> </Message></div>)}
    </div>

);

export default Messages;